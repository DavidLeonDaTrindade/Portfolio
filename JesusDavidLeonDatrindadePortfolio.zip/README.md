Este es el Readme de mi portfolio, las variantes que he introducido por ahora son una barra de navegacion o navbar, y e importado una libreria
para hacer uso de iconos y que asi quede mas vistozo el footer.
Los colores que voy a utilizar son el blanco y negro por que dan un toque elegante y de profesionalidad a la pagina web.
En la seccion de portfolio encontraras tres proyectos desarrollados por mi y actualmente funcionando.
En contacto he usado un formulario (Sin ruta de destino por el momento) para que cualquier usuario que quiera ponerse en contacto conmigo lo pueda hacer.
En curriculum he usado el mismo estilo minimalista del formulario, colocando información de interes que ire incrementando en el fururo.
En la sección de proyecto encontraras los enlaces a todas mis webs, no tendras que hacer uso de una pestaña nueva pues tiene el atributo _blank.
En los servicios he colocado alguna imagen de los lenguajes que mas domino y del que actualmente me encuentro aprendiendo.
Por supuesto toda la pagina esta en español eh ingles, iremos en un futuro incrementando informacion de interes.
