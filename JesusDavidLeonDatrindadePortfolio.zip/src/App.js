
import './App.css';
import MisRutas from './router/MisRutas';
function App() {
  
  return (
    <div className="App">
      <MisRutas></MisRutas>
    </div>
  );
}

export default App;
