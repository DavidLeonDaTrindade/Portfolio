export const LANGUAGES = [
    { label: "Spanish", code:"es"},
    { label: "English", code:"en"},
];